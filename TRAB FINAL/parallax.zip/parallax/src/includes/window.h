void framebuffer_size_callback(GLFWwindow * window, int w, int h);
